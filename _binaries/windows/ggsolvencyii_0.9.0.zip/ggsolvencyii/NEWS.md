# ggsolvencyii version 0.9.0

initial release, see how much intrest this package attracts before further development and documentation.

